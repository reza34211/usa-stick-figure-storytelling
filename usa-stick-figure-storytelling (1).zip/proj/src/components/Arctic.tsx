import React from "react";
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from "remotion";

export const INK = "#111";
export const C = {
  sky: "#DFF1FF",
  sea: "#8EC8F0",
  seaDeep: "#5BA7DB",
  ice: "#EAF6FF",
  rock: "#B9B3A8",
  land: "#EAD9B8",
  snow: "#FFFFFF",
  night: "#1F2A55",
  sun: "#FFC93C",
};

/** One continuous 1080x1920 canvas. */
export const Stage: React.FC<{children: React.ReactNode; bg?: string}> = ({children, bg = C.sky}) => (
  <AbsoluteFill style={{backgroundColor: bg}}>
    <svg width="100%" height="100%" viewBox="0 0 1080 1920" style={{position: "absolute"}}>
      {children}
    </svg>
  </AbsoluteFill>
);

export const useF = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  return {frame, fps, t: frame / fps, p: frame / Math.max(1, durationInFrames - 1), durationInFrames};
};

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * clamp01(k);
export const easeOut = (k: number) => 1 - Math.pow(1 - clamp01(k), 3);

export const Cloud: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill="#fff" stroke={INK} strokeWidth={7}>
    <path d="M -90 30 Q -120 30 -110 0 Q -100 -30 -60 -22 Q -40 -62 0 -50 Q 40 -60 62 -22 Q 110 -22 108 12 Q 112 34 80 30 Z" />
  </g>
);

export const Waves: React.FC<{y0: number; y1: number; color?: string}> = ({y0, y1, color = "#5BA7DB"}) => {
  const {frame} = useF();
  const rows: React.ReactNode[] = [];
  let i = 0;
  for (let y = y0; y < y1; y += 90) {
    for (let x = -60; x < 1140; x += 220) {
      const dx = Math.sin((frame + i * 17) / 24) * 18;
      rows.push(
        <path key={`${x}-${y}`} d={`M ${x + dx + (i % 2) * 90} ${y} q 25 -22 50 0 q 25 22 50 0`} fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" />
      );
      i++;
    }
  }
  return <g>{rows}</g>;
};

export const Flag: React.FC<{x: number; y: number; kind: "us" | "ru"; h?: number; dir?: 1 | -1}> = ({x, y, kind, h = 260, dir = 1}) => {
  const {frame} = useF();
  const w = 170;
  const fh = 110;
  const sk = Math.sin(frame / 7) * 3;
  return (
    <g transform={`translate(${x} ${y})`}>
      <line x1={0} y1={0} x2={0} y2={-h} stroke={INK} strokeWidth={8} strokeLinecap="round" />
      <g transform={`translate(0 ${-h}) scale(${dir} 1) skewY(${sk})`} stroke={INK} strokeWidth={5}>
        {kind === "ru" ? (
          <>
            <rect width={w} height={fh / 3} fill="#fff" />
            <rect y={fh / 3} width={w} height={fh / 3} fill="#1E50C8" />
            <rect y={(2 * fh) / 3} width={w} height={fh / 3} fill="#D52B1E" />
          </>
        ) : (
          <>
            {[0, 1, 2, 3, 4, 5, 6].map((i) => (
              <rect key={i} y={(i * fh) / 7} width={w} height={fh / 7} fill={i % 2 === 0 ? "#D52B1E" : "#fff"} />
            ))}
            <rect width={w * 0.45} height={(fh * 4) / 7} fill="#2B3F9E" />
          </>
        )}
        <rect width={w} height={fh} fill="none" />
      </g>
    </g>
  );
};

export const Snow: React.FC<{amount?: number}> = ({amount = 70}) => {
  const {frame} = useF();
  const dots: React.ReactNode[] = [];
  for (let i = 0; i < amount; i++) {
    const x0 = (i * 137) % 1080;
    const sp = 2.2 + (i % 5) * 0.7;
    const y = (frame * sp + i * 91) % 1980 - 30;
    const x = x0 + Math.sin((frame + i * 13) / 20) * 22;
    dots.push(<circle key={i} cx={x} cy={y} r={5 + (i % 3) * 2} fill="#fff" stroke="#9BB8D0" strokeWidth={2} />);
  }
  return <g>{dots}</g>;
};

export const Clock: React.FC<{cx: number; cy: number; r?: number; hour: number; minute: number; ring?: string}> = ({
  cx,
  cy,
  r = 110,
  hour,
  minute,
  ring = "#fff",
}) => {
  const ha = ((hour % 12) + minute / 60) * 30;
  const ma = minute * 6;
  const pt = (deg: number, len: number) => ({
    x: Math.sin((deg * Math.PI) / 180) * len,
    y: -Math.cos((deg * Math.PI) / 180) * len,
  });
  const H = pt(ha, r * 0.5);
  const M = pt(ma, r * 0.78);
  return (
    <g transform={`translate(${cx} ${cy})`} stroke={INK} strokeWidth={8} strokeLinecap="round">
      <circle r={r} fill={ring} />
      {[0, 90, 180, 270].map((d) => {
        const a = pt(d, r * 0.84);
        return <circle key={d} cx={a.x} cy={a.y} r={5} fill={INK} stroke="none" />;
      })}
      <line x1={0} y1={0} x2={H.x} y2={H.y} />
      <line x1={0} y1={0} x2={M.x} y2={M.y} strokeWidth={5} />
      <circle r={8} fill={INK} />
    </g>
  );
};

export const Sun: React.FC<{cx: number; cy: number; r?: number}> = ({cx, cy, r = 90}) => {
  const {frame} = useF();
  return (
    <g transform={`translate(${cx} ${cy}) rotate(${frame * 0.6})`} stroke={INK} strokeWidth={7} strokeLinecap="round">
      {Array.from({length: 12}).map((_, i) => (
        <line key={i} x1={r + 20} y1={0} x2={r + 55} y2={0} transform={`rotate(${i * 30})`} />
      ))}
      <circle r={r} fill={C.sun} />
    </g>
  );
};

export const Moon: React.FC<{cx: number; cy: number; r?: number}> = ({cx, cy, r = 85}) => (
  <g transform={`translate(${cx} ${cy})`} stroke={INK} strokeWidth={7}>
    <circle r={r} fill="#FFF3B0" />
    <circle cx={r * 0.45} cy={-r * 0.2} r={r * 0.85} fill={C.night} stroke="none" />
    <path d={`M ${-r * 0.2} ${-r * 0.95} A ${r} ${r} 0 0 0 ${-r * 0.2} ${r * 0.95}`} fill="none" />
  </g>
);

/** Animated measuring line with arrow heads. progress 0..1 */
export const Ruler: React.FC<{x1: number; x2: number; y: number; progress?: number; label?: string; color?: string}> = ({
  x1,
  x2,
  y,
  progress = 1,
  label,
  color = "#E53935",
}) => {
  const xe = x1 + (x2 - x1) * clamp01(progress);
  const mid = (x1 + x2) / 2;
  return (
    <g stroke={color} strokeWidth={9} strokeLinecap="round" fill="none">
      <line x1={x1} y1={y} x2={xe} y2={y} strokeDasharray="22 16" />
      <path d={`M ${x1 + 26} ${y - 22} L ${x1} ${y} L ${x1 + 26} ${y + 22}`} />
      {progress >= 1 ? <path d={`M ${x2 - 26} ${y - 22} L ${x2} ${y} L ${x2 - 26} ${y + 22}`} /> : null}
      {label && progress >= 0.9 ? (
        <text
          x={mid}
          y={y - 40}
          textAnchor="middle"
          fontFamily="'Arial Black', Arial, sans-serif"
          fontSize={64}
          fontWeight={900}
          fill="#FFC93C"
          stroke={INK}
          strokeWidth={12}
          paintOrder="stroke fill"
        >
          {label}
        </text>
      ) : null}
    </g>
  );
};
