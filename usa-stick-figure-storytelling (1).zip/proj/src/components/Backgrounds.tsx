import React from "react";
import {AbsoluteFill} from "remotion";

export type BackgroundKind = "street" | "room" | "office" | "plain";

const INK = "#111";

/** Simple flat-color environments. Add new kinds here. Ground line is at y = 830. */
export const Background: React.FC<{kind: BackgroundKind; scroll?: number}> = ({kind, scroll = 0}) => {
  return (
    <AbsoluteFill>
      <svg width="100%" height="100%" viewBox="0 0 1920 1080">
        <rect width="1920" height="1080" fill="#FAF7F0" />
        {kind === "street" && (
          <>
            <rect y="830" width="1920" height="250" fill="#CFE3F5" />
            <line x1="0" y1="830" x2="1920" y2="830" stroke={INK} strokeWidth={8} />
            <g transform={`translate(${-(scroll % 1200)} 0)`}>
              {[0, 1, 2].map((i) => (
                <g key={i} transform={`translate(${i * 600} 0)`}>
                  <rect x="60" y="420" width="260" height="410" fill={["#FF8A65", "#FFD54F", "#81C784"][i]} stroke={INK} strokeWidth={8} />
                  <rect x="110" y="470" width="60" height="70" fill="#fff" stroke={INK} strokeWidth={6} />
                  <rect x="210" y="470" width="60" height="70" fill="#fff" stroke={INK} strokeWidth={6} />
                  <rect x="150" y="700" width="70" height="130" fill="#8D6E63" stroke={INK} strokeWidth={6} />
                </g>
              ))}
              {[0, 1, 2].map((i) => (
                <g key={`b${i}`} transform={`translate(${i * 600 + 1200} 0)`}>
                  <rect x="60" y="420" width="260" height="410" fill={["#FF8A65", "#FFD54F", "#81C784"][i]} stroke={INK} strokeWidth={8} />
                </g>
              ))}
            </g>
          </>
        )}
        {kind === "room" && (
          <>
            <rect y="830" width="1920" height="250" fill="#E8D5B7" />
            <line x1="0" y1="830" x2="1920" y2="830" stroke={INK} strokeWidth={8} />
            <rect x="1250" y="220" width="360" height="300" fill="#BFE3FF" stroke={INK} strokeWidth={8} />
            <line x1="1430" y1="220" x2="1430" y2="520" stroke={INK} strokeWidth={6} />
          </>
        )}
        {kind === "office" && (
          <>
            <rect y="830" width="1920" height="250" fill="#D7DDE8" />
            <line x1="0" y1="830" x2="1920" y2="830" stroke={INK} strokeWidth={8} />
            <rect x="1150" y="620" width="520" height="30" fill="#8D6E63" stroke={INK} strokeWidth={8} />
            <line x1="1190" y1="650" x2="1190" y2="830" stroke={INK} strokeWidth={8} />
            <line x1="1630" y1="650" x2="1630" y2="830" stroke={INK} strokeWidth={8} />
          </>
        )}
      </svg>
    </AbsoluteFill>
  );
};
