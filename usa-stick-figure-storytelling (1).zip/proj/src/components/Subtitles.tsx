import React, {useEffect, useState} from "react";
import {AbsoluteFill, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {SUBTITLES} from "../config";

type Cue = {start: number; end: number; text: string};

const parseTime = (s: string): number => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return 0;
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4].padEnd(3, "0")) / 1000;
};

/** Parses SRT. Text and timestamps are kept exactly as in the file. */
export const parseSrt = (raw: string): Cue[] => {
  const blocks = raw.replace(/\r/g, "").trim().split(/\n\s*\n/);
  const cues: Cue[] = [];
  for (const b of blocks) {
    const lines = b.split("\n");
    const ti = lines.findIndex((l) => l.includes("-->"));
    if (ti < 0) continue;
    const [a, z] = lines[ti].split("-->");
    cues.push({start: parseTime(a), end: parseTime(z), text: lines.slice(ti + 1).join("\n")});
  }
  return cues;
};

/** PHASE 2: set SUBTITLES.srtFile in src/config.ts. Renders nothing while it is null. */
export const Subtitles: React.FC = () => {
  const [cues, setCues] = useState<Cue[]>([]);
  const [handle] = useState(() => (SUBTITLES.srtFile ? delayRender("Loading SRT") : null));
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  useEffect(() => {
    if (!SUBTITLES.srtFile || handle === null) return;
    fetch(staticFile(SUBTITLES.srtFile))
      .then((r) => r.text())
      .then((t) => {
        setCues(parseSrt(t));
        continueRender(handle);
      })
      .catch((e) => {
        console.error("SRT load failed", e);
        continueRender(handle);
      });
  }, [handle]);

  if (!SUBTITLES.srtFile) return null;
  const t = frame / fps - SUBTITLES.timeOffsetSec;
  const cue = cues.find((c) => t >= c.start && t < c.end);
  if (!cue) return null;

  const pos: React.CSSProperties =
    SUBTITLES.position === "top"
      ? {top: SUBTITLES.bottomOffsetPx}
      : SUBTITLES.position === "center"
        ? {top: "50%", transform: "translateY(-50%)"}
        : {bottom: SUBTITLES.bottomOffsetPx};

  return (
    <AbsoluteFill>
      <div style={{position: "absolute", left: 0, right: 0, display: "flex", justifyContent: "center", ...pos}}>
        <div
          style={{
            maxWidth: `${SUBTITLES.maxWidthPct}%`,
            textAlign: "center",
            fontFamily: "Arial, Helvetica, sans-serif",
            fontWeight: 700,
            fontSize: SUBTITLES.fontSize,
            lineHeight: 1.25,
            color: SUBTITLES.color,
            background: SUBTITLES.background,
            padding: "10px 28px",
            borderRadius: 14,
            whiteSpace: "pre-line",
          }}
        >
          {cue.text}
        </div>
      </div>
    </AbsoluteFill>
  );
};
