import React from "react";
import {Audio, Sequence, staticFile} from "remotion";
import {AUDIO} from "../config";
import {toFrames} from "../timing";

/** PHASE 2: set AUDIO.voiceover in src/config.ts. Renders nothing while it is null. */
export const VoiceoverAudio: React.FC = () => {
  if (!AUDIO.voiceover) return null;
  const offset = Math.round(AUDIO.voiceoverOffsetSec * 30);
  return (
    <Sequence from={Math.max(0, offset)} layout="none">
      <Audio src={staticFile(AUDIO.voiceover)} volume={AUDIO.volume} startFrom={offset < 0 ? -offset : 0} />
    </Sequence>
  );
};
void toFrames;
