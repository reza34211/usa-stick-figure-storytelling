import React from "react";

export type Expression = "happy" | "sad" | "shocked" | "angry" | "neutral";

export type StickFigureProps = {
  x: number; // center x (px)
  y: number; // ground y (px, feet level)
  scale?: number;
  flip?: boolean; // face left
  walkPhase?: number; // 0..1 loops a walk cycle; undefined = standing
  armLeft?: number; // degrees, 0 = hanging down
  armRight?: number;
  expression?: Expression;
  shirt?: string;
  skin?: string;
  hair?: string | null; // null = no hair
  hat?: "beanie" | "ushanka" | "helmet" | null;
};

const INK = "#111";

const Face: React.FC<{expression: Expression}> = ({expression}) => {
  const eyes =
    expression === "shocked" ? (
      <>
        <circle cx={-22} cy={-8} r={9} fill="#fff" stroke={INK} strokeWidth={5} />
        <circle cx={22} cy={-8} r={9} fill="#fff" stroke={INK} strokeWidth={5} />
        <circle cx={-22} cy={-8} r={3} fill={INK} />
        <circle cx={22} cy={-8} r={3} fill={INK} />
      </>
    ) : (
      <>
        <circle cx={-22} cy={-8} r={5} fill={INK} />
        <circle cx={22} cy={-8} r={5} fill={INK} />
      </>
    );
  const brows =
    expression === "angry" ? (
      <>
        <line x1={-34} y1={-26} x2={-12} y2={-18} stroke={INK} strokeWidth={6} strokeLinecap="round" />
        <line x1={34} y1={-26} x2={12} y2={-18} stroke={INK} strokeWidth={6} strokeLinecap="round" />
      </>
    ) : expression === "sad" ? (
      <>
        <line x1={-34} y1={-20} x2={-12} y2={-28} stroke={INK} strokeWidth={6} strokeLinecap="round" />
        <line x1={34} y1={-20} x2={12} y2={-28} stroke={INK} strokeWidth={6} strokeLinecap="round" />
      </>
    ) : null;
  const mouth =
    expression === "happy" ? (
      <path d="M -24 20 Q 0 46 24 20" fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" />
    ) : expression === "sad" || expression === "angry" ? (
      <path d="M -22 34 Q 0 14 22 34" fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" />
    ) : expression === "shocked" ? (
      <ellipse cx={0} cy={28} rx={11} ry={15} fill="#fff" stroke={INK} strokeWidth={5} />
    ) : (
      <line x1={-18} y1={28} x2={18} y2={28} stroke={INK} strokeWidth={6} strokeLinecap="round" />
    );
  return (
    <g>
      {eyes}
      {brows}
      {mouth}
    </g>
  );
};

/** Reusable stick figure. Local origin = feet. Height about 330 px at scale 1. */
export const StickFigure: React.FC<StickFigureProps> = ({
  x,
  y,
  scale = 1,
  flip = false,
  walkPhase,
  armLeft = 15,
  armRight = -15,
  expression = "neutral",
  shirt = "#2F6BFF",
  skin = "#FFE2B8",
  hair = "#6B3F1D",
  hat = null,
}) => {
  const walking = walkPhase !== undefined;
  const swing = walking ? Math.sin(walkPhase! * Math.PI * 2) : 0;
  const legL = swing * 26;
  const legR = -swing * 26;
  const aL = walking ? armLeft - swing * 30 : armLeft;
  const aR = walking ? armRight + swing * 30 : armRight;
  const bob = walking ? Math.abs(Math.sin(walkPhase! * Math.PI * 2)) * -6 : 0;

  const limb = (angle: number, len: number) => {
    const r = (angle * Math.PI) / 180;
    return {x2: Math.sin(r) * len, y2: Math.cos(r) * len};
  };
  const L = limb(legL, 130);
  const R = limb(legR, 130);
  const AL = limb(aL, 100);
  const AR = limb(aR, 100);

  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`}>
      <g transform={`translate(0 ${bob})`} stroke={INK} strokeWidth={9} strokeLinecap="round" fill="none">
        {/* legs */}
        <line x1={0} y1={-135} x2={L.x2} y2={-135 + L.y2} />
        <line x1={0} y1={-135} x2={R.x2} y2={-135 + R.y2} />
        {/* torso */}
        <line x1={0} y1={-135} x2={0} y2={-240} stroke={shirt} strokeWidth={16} />
        <line x1={0} y1={-135} x2={0} y2={-240} strokeWidth={0} />
        {/* arms */}
        <line x1={0} y1={-225} x2={AL.x2} y2={-225 + AL.y2} />
        <line x1={0} y1={-225} x2={AR.x2} y2={-225 + AR.y2} />
        {/* head */}
        <g transform="translate(0 -300)">
          <circle r={58} fill={skin} />
          {hair ? <path d="M -56 -12 Q -40 -62 0 -62 Q 40 -62 56 -12 Q 20 -40 -56 -12 Z" fill={hair} /> : null}
          <Face expression={expression} />
          {hat === "beanie" ? (
            <g>
              <path d="M -58 -14 Q -58 -80 0 -80 Q 58 -80 58 -14 Z" fill="#E53935" />
              <rect x={-60} y={-24} width={120} height={18} rx={6} fill="#B71C1C" />
              <circle cx={0} cy={-86} r={13} fill="#fff" />
            </g>
          ) : null}
          {hat === "ushanka" ? (
            <g>
              <path d="M -60 -10 Q -60 -78 0 -78 Q 60 -78 60 -10 Z" fill="#7B5B3A" />
              <rect x={-66} y={-26} width={132} height={16} rx={6} fill="#4E3B26" />
              <rect x={-72} y={-20} width={20} height={54} rx={9} fill="#4E3B26" />
              <rect x={52} y={-20} width={20} height={54} rx={9} fill="#4E3B26" />
            </g>
          ) : null}
          {hat === "helmet" ? (
            <g>
              <path d="M -62 -8 Q -62 -78 0 -78 Q 62 -78 62 -8 Z" fill="#4F6B3A" />
              <rect x={-68} y={-20} width={136} height={12} rx={5} fill="#3A4F2A" />
            </g>
          ) : null}
        </g>
      </g>
    </g>
  );
};
