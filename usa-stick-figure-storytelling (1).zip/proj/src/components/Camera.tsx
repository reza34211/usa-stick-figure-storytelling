import React from "react";
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from "remotion";

export type CameraType = "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "shake" | "none";

export const Camera: React.FC<{
  type?: CameraType;
  strength?: number; // 0.08 gentle - 0.25 dramatic
  focusX?: number; // 0-100
  focusY?: number; // 0-100
  children: React.ReactNode;
}> = ({type = "none", strength = 0.12, focusX = 50, focusY = 50, children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames, width} = useVideoConfig();
  const p = interpolate(frame, [0, Math.max(1, durationInFrames - 1)], [0, 1], {
    easing: Easing.inOut(Easing.cubic),
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  let scale = 1;
  let tx = 0;
  let ty = 0;
  const m = (strength / 2) * width;
  if (type === "zoom-in") scale = 1 + strength * p;
  if (type === "zoom-out") scale = 1 + strength * (1 - p);
  if (type === "pan-left") {
    scale = 1 + strength;
    tx = -m + 2 * m * p;
  }
  if (type === "pan-right") {
    scale = 1 + strength;
    tx = m - 2 * m * p;
  }
  if (type === "shake") {
    scale = 1.03;
    tx = Math.sin(frame * 1.9) * 6;
    ty = Math.cos(frame * 2.3) * 5;
  }
  return (
    <AbsoluteFill
      style={{transform: `translate(${tx}px, ${ty}px) scale(${scale})`, transformOrigin: `${focusX}% ${focusY}%`}}
    >
      {children}
    </AbsoluteFill>
  );
};
