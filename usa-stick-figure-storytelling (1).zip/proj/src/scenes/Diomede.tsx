import React from "react";
import {StickFigure} from "../components/StickFigure";
import {C, Cloud, Clock, Flag, INK, Moon, Ruler, Snow, Stage, Sun, Waves, clamp01, easeOut, lerp, useF} from "../components/Arctic";

const LAND_Y = 1240; // ground line for ground-level scenes
const font: React.CSSProperties = {fontFamily: "'Arial Black', Arial, sans-serif", fontWeight: 900};

const Label: React.FC<{x: number; y: number; text: string; size?: number; scale?: number}> = ({x, y, text, size = 70, scale = 1}) => (
  <text
    x={x}
    y={y}
    textAnchor="middle"
    style={font}
    fontSize={size}
    fill="#FFC93C"
    stroke={INK}
    strokeWidth={size * 0.18}
    paintOrder="stroke fill"
    transform={`translate(${x} ${y}) scale(${scale}) translate(${-x} ${-y})`}
  >
    {text}
  </text>
);

/** Shared ground-level set: Russia (left) and USA (right) shores with water between. */
const Shores: React.FC<{ice?: number; night?: boolean; flags?: boolean; bridge?: boolean}> = ({
  ice = 0,
  night = false,
  flags = false,
  bridge = false,
}) => (
  <g>
    {night ? (
      <>
        <rect x={0} y={0} width={540} height={LAND_Y + 20} fill={C.night} />
        <rect x={540} y={0} width={540} height={LAND_Y + 20} fill={C.sky} />
      </>
    ) : null}
    <rect x={0} y={LAND_Y} width={1080} height={900} fill={C.sea} />
    {night ? <rect x={0} y={LAND_Y} width={540} height={900} fill="#2F4A8A" /> : null}
    <Waves y0={LAND_Y + 120} y1={1900} color={night ? "#6D8FD0" : C.seaDeep} />
    <rect x={0} y={LAND_Y} width={1080} height={900} fill={C.ice} opacity={ice} />
    <rect x={-60} y={LAND_Y} width={390} height={900} rx={60} fill={C.land} stroke={INK} strokeWidth={8} />
    <rect x={750} y={LAND_Y} width={390} height={900} rx={60} fill={C.land} stroke={INK} strokeWidth={8} />
    <rect x={-60} y={LAND_Y - 6} width={390} height={26} rx={13} fill="#fff" opacity={ice} />
    <rect x={750} y={LAND_Y - 6} width={390} height={26} rx={13} fill="#fff" opacity={ice} />
    {bridge ? <rect x={290} y={LAND_Y} width={500} height={46} rx={20} fill={C.ice} stroke={INK} strokeWidth={8} /> : null}
    {flags ? (
      <>
        <Flag x={40} y={LAND_Y} kind="ru" />
        <Flag x={1040} y={LAND_Y} kind="us" dir={-1} />
      </>
    ) : null}
  </g>
);

// ---------------- S01: hook ----------------
export const S01: React.FC = () => {
  const {frame, t} = useF();
  const wave = 100 + Math.sin(frame / 5) * 25;
  return (
    <Stage>
      <Cloud x={200 + frame * 0.5} y={330} s={1.3} />
      <Cloud x={600} y={640} s={0.8} />
      <Cloud x={820 - frame * 0.4} y={420} s={1} />
      <Shores />
      <StickFigure x={170} y={LAND_Y} scale={1.2} hat="ushanka" shirt="#D52B1E" armLeft={20} armRight={-wave} expression="happy" hair={null} />
      <StickFigure x={910} y={LAND_Y} scale={1.2} flip hat="beanie" shirt="#2B3F9E" armLeft={20} armRight={-30} expression={t > 1 ? "shocked" : "neutral"} />
      <Ruler x1={330} x2={750} y={980} progress={easeOut((t - 1.8) / 1.6)} label="2 MILES" />
    </Stage>
  );
};

// ---------------- S02: teaser, "connected?" ----------------
export const S02: React.FC = () => {
  const {frame, t} = useF();
  const bob = Math.sin(frame / 8) * 14;
  const pop = easeOut(t / 0.6);
  return (
    <Stage>
      <Cloud x={300 + frame * 0.4} y={260} s={1.2} />
      <Shores />
      <StickFigure x={170} y={LAND_Y} scale={1.2} hat="ushanka" shirt="#D52B1E" armLeft={20} armRight={-130} expression="neutral" hair={null} />
      <StickFigure x={910} y={LAND_Y} scale={1.2} flip hat="beanie" shirt="#2B3F9E" armLeft={20} armRight={-130} expression="neutral" />
      <g transform={`translate(540 ${930 + bob}) scale(${pop})`}>
        <g fill="none" stroke={INK} strokeWidth={14} strokeLinecap="round">
          <ellipse cx={-48} cy={0} rx={64} ry={38} transform="rotate(-25 -48 0)" stroke="#2B3F9E" />
          <ellipse cx={48} cy={0} rx={64} ry={38} transform="rotate(-25 48 0)" stroke="#D52B1E" />
        </g>
        <Label x={0} y={-130} text="?" size={190} />
      </g>
    </Stage>
  );
};

// ---------------- S03: map, Bering Strait ----------------
const MapBase: React.FC = () => (
  <>
    <rect width={1080} height={1920} fill={C.sea} />
    <Waves y0={80} y1={1900} />
    <path d="M -20 -20 L 400 -20 Q 330 420 410 700 Q 300 1000 390 1300 Q 330 1600 410 1940 L -20 1940 Z" fill="#F4C7BD" stroke={INK} strokeWidth={9} />
    <path d="M 1100 -20 L 690 -20 Q 760 420 670 700 Q 780 1000 690 1300 Q 760 1600 680 1940 L 1100 1940 Z" fill="#C6DBF4" stroke={INK} strokeWidth={9} />
  </>
);

export const S03: React.FC = () => {
  const {frame, t} = useF();
  const pulse = 1 + Math.sin(frame / 6) * 0.12;
  return (
    <Stage>
      <MapBase />
      <Flag x={200} y={620} kind="ru" h={200} />
      <Flag x={880} y={620} kind="us" h={200} dir={-1} />
      {/* two tiny islands */}
      <g stroke={INK} strokeWidth={7}>
        <ellipse cx={520} cy={940} rx={30} ry={22} fill={C.rock} />
        <ellipse cx={580} cy={985} rx={22} ry={16} fill={C.rock} />
      </g>
      <circle cx={550} cy={962} r={80 * pulse} fill="none" stroke="#E53935" strokeWidth={9} strokeDasharray="20 14" opacity={clamp01((t - 1.5) / 0.6)} />
    </Stage>
  );
};

// ---------------- S04: two Diomede islands ----------------
const Island: React.FC<{cx: number; cy: number; rx: number; ry: number; snow?: boolean}> = ({cx, cy, rx, ry, snow = true}) => (
  <g stroke={INK} strokeWidth={9}>
    <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={C.rock} />
    {snow ? <path d={`M ${cx - rx * 0.6} ${cy - ry * 0.55} Q ${cx} ${cy - ry * 1.05} ${cx + rx * 0.6} ${cy - ry * 0.55} Q ${cx} ${cy - ry * 0.2} ${cx - rx * 0.6} ${cy - ry * 0.55} Z`} fill="#fff" strokeWidth={6} /> : null}
  </g>
);

export const S04: React.FC = () => {
  const {t} = useF();
  return (
    <Stage bg={C.sea}>
      <rect width={1080} height={1920} fill={C.sea} />
      <Waves y0={60} y1={1900} />
      <Island cx={250} cy={980} rx={230} ry={190} />
      <Island cx={830} cy={1000} rx={190} ry={130} />
      <Flag x={250} y={900} kind="ru" h={220} />
      <Flag x={830} y={920} kind="us" h={220} dir={-1} />
      <Ruler x1={480} x2={640} y={1300} progress={easeOut((t - 1.0) / 1.6)} label="2.4 MILES" />
    </Stage>
  );
};

// ---------------- S05: Little Diomede (US) ----------------
const House: React.FC<{x: number; y: number; color: string; s?: number}> = ({x, y, color, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke={INK} strokeWidth={7} strokeLinejoin="round">
    <rect x={-45} y={-70} width={90} height={70} fill={color} />
    <path d="M -58 -70 L 0 -122 L 58 -70 Z" fill="#fff" />
    <rect x={-12} y={-42} width={24} height={42} fill="#8D6E63" />
  </g>
);

export const S05: React.FC = () => {
  const {frame, t} = useF();
  const n = Math.round(lerp(0, 82, (t - 2.5) / 3));
  return (
    <Stage bg={C.sky}>
      <rect y={900} width={1080} height={1020} fill={C.sea} />
      <Waves y0={1500} y1={1900} />
      <Cloud x={250 + frame * 0.4} y={260} s={1.2} />
      <g stroke={INK} strokeWidth={9}>
        <ellipse cx={540} cy={1300} rx={560} ry={300} fill={C.rock} />
        <path d="M -20 1250 Q 540 960 1100 1250 Q 540 1160 -20 1250 Z" fill="#fff" strokeWidth={6} />
      </g>
      <House x={250} y={1190} color="#FF8A65" />
      <House x={420} y={1150} color="#FFD54F" s={1.1} />
      <House x={650} y={1150} color="#81C784" s={1.1} />
      <House x={820} y={1190} color="#64B5F6" />
      <Flag x={540} y={1135} kind="us" h={230} />
      <StickFigure x={330} y={1250} scale={0.5} walkPhase={t * 1.1} hat="beanie" shirt="#2B3F9E" expression="happy" />
      <StickFigure x={760} y={1260} scale={0.5} flip hat="beanie" shirt="#FF4B3E" armRight={-110} expression="happy" />
      <Label x={540} y={520} text={`${n} PEOPLE`} size={104} scale={easeOut(t / 0.5)} />
    </Stage>
  );
};

// ---------------- S06: Big Diomede (Russia) ----------------
export const S06: React.FC = () => {
  const {frame, t} = useF();
  return (
    <Stage bg={C.sky}>
      <rect y={900} width={1080} height={1020} fill={C.sea} />
      <Waves y0={1500} y1={1900} />
      <Cloud x={800 - frame * 0.4} y={280} s={1.1} />
      <g stroke={INK} strokeWidth={9}>
        <ellipse cx={540} cy={1300} rx={540} ry={290} fill={C.rock} />
        <path d="M -20 1260 Q 540 980 1100 1260 Q 540 1170 -20 1260 Z" fill="#fff" strokeWidth={6} />
      </g>
      <g stroke={INK} strokeWidth={7}>
        <rect x={760} y={1060} width={130} height={110} fill="#8C9A7B" />
        <rect x={745} y={1030} width={160} height={34} fill="#5E6B4F" />
      </g>
      <Flag x={260} y={1170} kind="ru" h={240} />
      <StickFigure x={540} y={1230} scale={0.85} hat="helmet" shirt="#4F6B3A" armLeft={10} armRight={-(125 + Math.sin(t * 2) * 6)} expression="neutral" hair={null} />
    </Stage>
  );
};

// ---------------- S07: closest American town ----------------
export const S07: React.FC = () => {
  const {frame, t} = useF();
  return (
    <Stage>
      <Cloud x={350 + frame * 0.4} y={240} s={1.2} />
      <Shores />
      <Flag x={40} y={LAND_Y} kind="ru" />
      <House x={880} y={LAND_Y} color="#FF8A65" s={0.8} />
      <House x={990} y={LAND_Y} color="#FFD54F" s={0.8} />
      <StickFigure x={800} y={LAND_Y} scale={1.2} flip hat="beanie" shirt="#2B3F9E" armRight={-150} expression="neutral" />
      <Ruler x1={330} x2={750} y={1000} progress={easeOut((t - 1.2) / 1.6)} label="2 MILES" />
    </Stage>
  );
};

// ---------------- S08: winter, water freezes ----------------
export const S08: React.FC = () => {
  const {p} = useF();
  const ice = easeOut(p * 1.3);
  return (
    <Stage bg={lerp(0, 1, ice) > 0.5 ? "#E6F1FA" : C.sky}>
      <Shores ice={ice} flags />
      <g stroke="#9BB8D0" strokeWidth={5} fill="none" opacity={ice}>
        <path d="M 400 1300 L 480 1380 L 450 1480 M 700 1250 L 640 1360 L 690 1450 M 540 1500 L 600 1620" />
      </g>
      <Snow amount={80} />
    </Stage>
  );
};

// ---------------- S09: ice bridge, walking across ----------------
export const S09: React.FC = () => {
  const {t} = useF();
  const x = lerp(840, 230, (t - 0.8) / 6);
  return (
    <Stage bg="#E6F1FA">
      <Shores ice={1} flags bridge />
      <StickFigure x={x} y={LAND_Y} scale={1.2} flip walkPhase={t * 1.3} hat="beanie" shirt="#2B3F9E" expression="happy" />
      <Snow amount={45} />
    </Stage>
  );
};

// ---------------- S10: International Date Line ----------------
const Stars: React.FC = () => {
  const {frame} = useF();
  return (
    <g fill="#FFF3B0">
      {[[100, 180], [220, 340], [420, 120], [330, 760], [90, 640], [470, 420], [150, 900]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={6 + ((frame / 10 + i) % 3)} />
      ))}
    </g>
  );
};

const DateLine: React.FC<{glow?: number}> = ({glow = 1}) => (
  <line x1={540} y1={0} x2={540} y2={1920} stroke="#E53935" strokeWidth={12} strokeDasharray="34 22" opacity={0.5 + 0.5 * glow} />
);

export const S10: React.FC = () => {
  const {frame, t} = useF();
  const pop = easeOut(t / 0.6);
  return (
    <Stage>
      <Shores night flags bridge />
      <Stars />
      <Moon cx={270} cy={380} />
      <Sun cx={810} cy={380} />
      <DateLine glow={Math.sin(frame / 6)} />
      <Clock cx={270} cy={760} hour={12} minute={(t * 6) % 60} ring="#fff" />
      <Clock cx={810} cy={760} hour={3} minute={(t * 6) % 60} ring="#fff" />
      <Label x={540} y={1640} text="+21 HOURS" size={110} scale={pop} />
    </Stage>
  );
};

// ---------------- S11: crossing = time traveler ----------------
export const S11: React.FC = () => {
  const {frame, t} = useF();
  const x = lerp(840, 230, (t - 0.8) / 6.5);
  const near = Math.abs(x - 540) < 130;
  const crossed = x < 540;
  const spin = near ? frame * 14 : frame * 2;
  return (
    <Stage>
      <Shores night flags bridge />
      <Stars />
      <Moon cx={270} cy={380} />
      <Sun cx={810} cy={380} />
      <DateLine glow={1} />
      <StickFigure x={x} y={LAND_Y} scale={1.2} flip walkPhase={t * 1.3} hat="beanie" shirt="#2B3F9E" expression={near ? "shocked" : crossed ? "happy" : "neutral"} />
      <Clock cx={x} cy={LAND_Y - 610} r={95} hour={spin / 12} minute={spin} ring="#FFF3B0" />
      {near ? (
        <g fill="none" stroke="#8A4FFF" strokeWidth={10} strokeLinecap="round" opacity={0.9}>
          <circle cx={x} cy={LAND_Y - 200} r={250 + Math.sin(frame / 2) * 18} strokeDasharray="30 24" />
        </g>
      ) : null}
    </Stage>
  );
};
