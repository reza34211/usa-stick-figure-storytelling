// =====================================================================
// registry.ts - THE SCENE LIST (story order). durationSec = voiceover slot.
// Timing is estimated from the script at 150 words/min (2.5 words/sec).
// When the real MP3 arrives, adjust durationSec to match (see docs/scene-breakdown.md).
// =====================================================================
import type React from "react";
import type {CameraType} from "../components/Camera";
import {S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11} from "./Diomede";

export type TransitionType = "cut" | "fade" | "slide-left" | "slide-right" | "wipe";

export type SceneEntry = {
  id: string;
  title: string;
  durationSec: number;
  component: React.FC;
  camera?: {type: CameraType; strength?: number; focusX?: number; focusY?: number};
  transition?: {type: TransitionType; durationSec?: number};
};

export const scenes: SceneEntry[] = [
  {id: "01", title: "Hook: two figures, 2 miles apart", durationSec: 8, component: S01, camera: {type: "zoom-in", strength: 0.12, focusY: 55}, transition: {type: "cut"}},
  {id: "02", title: "Teaser: connected sometimes?", durationSec: 5.2, component: S02, camera: {type: "zoom-in", strength: 0.14, focusY: 45}, transition: {type: "wipe", durationSec: 0.5}},
  {id: "03", title: "Map: Bering Strait", durationSec: 5.6, component: S03, camera: {type: "zoom-in", strength: 0.35, focusX: 51, focusY: 50}, transition: {type: "fade", durationSec: 0.5}},
  {id: "04", title: "Two Diomede Islands, 2.4 miles", durationSec: 9.6, component: S04, camera: {type: "zoom-out", strength: 0.12, focusY: 55}, transition: {type: "fade", durationSec: 0.5}},
  {id: "05", title: "Little Diomede, population 82", durationSec: 11.2, component: S05, camera: {type: "pan-left", strength: 0.12}, transition: {type: "slide-left", durationSec: 0.5}},
  {id: "06", title: "Big Diomede, military only", durationSec: 5.6, component: S06, camera: {type: "zoom-in", strength: 0.12, focusY: 60}, transition: {type: "slide-right", durationSec: 0.5}},
  {id: "07", title: "Closest American town to Russia", durationSec: 6, component: S07, camera: {type: "zoom-in", strength: 0.1, focusX: 70, focusY: 60}, transition: {type: "cut"}},
  {id: "08", title: "Winter: the water freezes", durationSec: 4.4, component: S08, camera: {type: "zoom-out", strength: 0.1}, transition: {type: "fade", durationSec: 0.4}},
  {id: "09", title: "Ice bridge: walking across", durationSec: 8, component: S09, camera: {type: "zoom-in", strength: 0.12, focusY: 58}, transition: {type: "wipe", durationSec: 0.5}},
  {id: "10", title: "International Date Line, 21 hours", durationSec: 7.6, component: S10, camera: {type: "zoom-in", strength: 0.1, focusY: 40}, transition: {type: "cut"}},
  {id: "11", title: "Cross the line: time traveler", durationSec: 9.2, component: S11, camera: {type: "zoom-in", strength: 0.12, focusY: 58}},
];
