# Scene Breakdown & Voiceover Timing (9:16, 1080x1920, 30 FPS)

Source: user's original script (unchanged). Durations estimated at 150 words/min (2.5 words/sec).
Replace with real values when the MP3 arrives: edit `durationSec` in `src/scenes/registry.ts`.

Story: US and Russia are only ~2 miles apart (Diomede Islands); winter ice bridge; International Date Line (21 hours).
Characters: American (red beanie, blue shirt), Russian (brown ushanka, red shirt), Soldier (green helmet, Big Diomede).

| # | Start | Dur | Script part (voiceover slot) | Visual | Camera | Transition |
|---|-------|-----|------------------------------|--------|--------|------------|
| 01 | 0.0s | 8.0 | Not all Americans know that the US and Russia are actually much closer to each other, just 2 miles apart. | Russian waves, American shocked, "2 MILES" ruler | Zoom in | Cut |
| 02 | 8.0 | 5.2 | And more than that, they are even connected sometimes, and here is why. | Same shore, chain rings and "?" | Zoom in | Wipe |
| 03 | 13.2 | 5.6 | The countries are separated by the Bering Strait, and if we look closer here, | Top-down map, Russia left, Alaska right, two tiny islands circled | Zoom in to islands | Fade |
| 04 | 18.8 | 9.6 | we can see two tiny Diomede Islands, which are 2.4 miles apart and divide the mainland of the US and the mainland of Russia. | Two islands with flags, "2.4 MILES" ruler | Zoom out | Fade |
| 05 | 28.4 | 11.2 | Little Diomede belongs to the USA, and it is home to one of the most isolated towns in the USA called Diomede, with a population of 82 people. | Village on island, US flag, counter to "82 PEOPLE" | Pan left | Slide |
| 06 | 39.6 | 5.6 | Big Diomede belongs to Russia, and it is uninhabited, only military personnel are present. | Empty island, Russian flag, soldier on guard | Zoom in | Slide |
| 07 | 45.2 | 6.0 | Therefore, Diomede is the closest American town to Russia, separated by 2 miles of water. | American looks across water at Russia, "2 MILES" | Zoom in | Cut |
| 08 | 51.2 | 4.4 | And the point is that in the winter, the water freezes | Water turns to ice, snow falls | Zoom out | Fade |
| 09 | 55.6 | 8.0 | and creates an ice bridge between the two countries, and thus making it possible to cross the border by land. | American walks across ice bridge | Zoom in | Wipe |
| 10 | 63.6 | 7.6 | Interesting that there is an International Date Line between these two islands, the difference between them is 21 hours, | Night (Russia) vs day (US), date line, two clocks, "+21 HOURS" | Zoom in | Cut |
| 11 | 71.2 | 9.2 | and if you cross the border from the US side, you will be in the future and become a kind of time traveler. | American crosses the line, clock spins, shocked then happy | Zoom in | End |

Total about 80.4 seconds (2412 frames).
Note: the user's script ends with "..." after "time traveler". It was kept as-is; no ending was added.
